jQuery Mobile React Example
===========================

This example demonstrates how jQuery Mobile applications can be built with React.

The source code is based on jQuery Mobile's [pages-multi-page example](https://github.com/jquery/jquery-mobile/tree/master/demos/pages-multi-page).
